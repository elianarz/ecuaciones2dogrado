//
//  ViewController.swift
//  ecuaciones_2do_grado
//
//  Created by Elian Arizmendi on 27/08/21.
//

import UIKit

class ViewController: UIViewController {
    
    ///
    @IBOutlet weak var textInputA: UITextField!
    
    @IBOutlet weak var textInputB: UITextField!
    
    @IBOutlet weak var textInputC: UITextField!
    
    @IBOutlet weak var raiz1: UITextField!

    @IBOutlet weak var raiz2: UITextField!
    ///
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


    var a = Double()
    var b = Double()
    var c = Double()
    var delta = Double()
    var x1 = Double()
    var x2 = Double()
    var x1i = Double()
    var x2i = Double()
    var ecuacionLinear = Bool()
    var ecuacionCuadratica = Bool()

    
    func evaluarEcuacion() {
        
        if a == 0 {
            
            //ecuacionLinear = true
            ecuacionCuadratica = false
            
        } else if a != 0 {
            
            ecuacionCuadratica = true
            //ecuacionLinear = false
        }
    }
    
    
    func linear() -> Double {
        
        x1 = -c / b
        raiz2.isHidden = true
        raiz1.text = "x = \(x1)"
        
        return x1
    }


    func Delta() -> Double {
        
        delta = (b * b) - (4 * a * c)
        
        return delta
    }

    func cuadratica() {
        
        if delta >= 0 {
            x1 = ( -b + sqrt(delta)) / 2*a
            x2 = ( -b - sqrt(delta)) / 2*a
            
            raiz1.isHidden = false
            raiz2.isHidden = false
            
            raiz1.text = String(x1)
            raiz2.text = String(x2)

        } else if delta < 0 {

            x1 = ( -b ) / (2 * a)
            x1i = (sqrt(-delta) / (2 * a))
            x2 = ( -b ) / (2 * a)
            x2i = (sqrt(-delta) / (2 * a))

            raiz1.isHidden = false
            raiz2.isHidden = false
            
            raiz1.text = String(format: "%.2f", x1) + " + "  + String(format: "%.2f",x1i) + " i"
            raiz2.text = String(format: "%.2f", x2) + " - " + String(format: "%.2f",x2i) + " i"

        }
    }


    func resolver() {
        
        if ecuacionLinear == true {
            x1 = -c / b
            raiz2.isHidden = true
            raiz1.text = String(x1)
            
        } else if ecuacionCuadratica == true {
            delta = (b * b) - (4 * a * c)
            cuadratica()
        }
    }
    
    
    
    @IBAction func buttonResolver(_ sender: UIButton) {
        
        a = Double(textInputA.text!)!
        b = Double(textInputB.text!)!
        c = Double(textInputC.text!)!
        evaluarEcuacion()
        resolver()
        
    }
}

