//
//  viewcontroller.swift
//  viewcontroller
//
//  Created by Elian Arizmendi on 27/08/21.
//

import XCTest

@testable import ecuaciones_2do_grado

class ecuaciones_2do_grado: XCTestCase {
    
   //pendientes...
         

}
